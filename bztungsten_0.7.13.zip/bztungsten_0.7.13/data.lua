require("tungsten-ore")
require("tungsten-ore-particle")
require("tungsten-recipe")
require("tungsten-enriched")   -- Enriched for Krastorio 2
require("tungsten-recipe-se")  -- Space Exploration special recipes (depends on K2 if present)
require("tungsten-compressed")
require("advanced-carbon-furnace")
require("tungsten-sim") -- menu simulation
