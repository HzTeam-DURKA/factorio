if omni and omni.matter then
  omni.matter.add_resource("tungsten-ore", omni.matter.get_ore_tier("iron-ore"))
end
