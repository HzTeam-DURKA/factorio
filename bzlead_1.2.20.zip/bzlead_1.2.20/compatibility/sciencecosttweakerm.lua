local util = require("data-util")

util.replace_some_ingredient("sct-t2-wafer-stamp", "iron-plate", 2, "lead-plate", 2)

