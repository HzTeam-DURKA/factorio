# Lead

[factorio mod page](https://mods.factorio.com/mod/bzlead)

Adds lead ore and plates to the base game, an early-game resource.
Modifies ammunition, pipes, batteries and a few other things. Further mod compatibility is planned.

## Version History
See changelog.txt

## Created by

- [brevven](https://mods.factorio.com/user/brevven) (code, design, graphics)
- [snouz](https://github.com/snouz) (graphics)

### Compatibility & bug fixes
- [nihilistzsche](https://github.com/nihilistzsche)
- [orangedude27](https://github.com/orangedude27)


### Localization
- [Sakuro](https://github.com/sakuro) (ja)
- [TheoMarque](https://github.com/TheoMarque) (pl)
- [Spectrus1702](https://github.com/Spectrus1702) (ru)
- [Yokmp](https://github.com/Yokmp) (de)
- [PlexPt](https://github.com/PlexPt) (zh\_CN)
- [S3BA](https://github.com/S3BA-pl) (pl)
- [x2605](https://github.com/x2605) (ko)
- [Pergamum663](https://github.com/Pergamum663) (ru)
- [RiCZrd](https://mods.factorio.com/user/RiCZrd) (cs)
- [sunnytan53](https://github.com/sunnytan53) (zh\_CN)
