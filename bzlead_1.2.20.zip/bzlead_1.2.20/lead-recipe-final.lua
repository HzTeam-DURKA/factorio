-- Titanium recipe & tech changes
-- These are in "final" for compatibility with other mods such as Space Exploration, AAI and Krastorio 2

local util = require("__bztitanium__.data-util");

if (mods["bobrevamp"] and not mods["bobplates"] and not mods["angelssmelting"]) then
  -- TODO
end


