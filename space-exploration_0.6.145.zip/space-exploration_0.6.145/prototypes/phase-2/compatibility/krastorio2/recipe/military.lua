local data_util = require("data_util")

-- Radars
data_util.replace_or_add_ingredient("radar","iron-plate","steel-plate",15)
