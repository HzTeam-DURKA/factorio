local util = require("data-util");

util.replace_ingredient("sct-t2-reaction-nodes", "iron-plate", "solder")
