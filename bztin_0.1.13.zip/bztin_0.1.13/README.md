# Tin

[factorio mod page](https://mods.factorio.com/mod/bztin)

Adds tin to the base game

## Version History
See changelog.txt

## Created by

- [brevven](https://mods.factorio.com/user/brevven) (code, design, graphics)

## Thanks to 
- [snouz](https://github.com/snouz) (logo inspiration, ore graphics templates)

### Compatibility
- [nihilistzsche](https://github.com/nihilistzsche)

### Localization

- [Pergamum663](https://github.com/Pergamum663) (ru)
- [RiCZrd](https://mods.factorio.com/user/RiCZrd) (cs)
- [Sakuro](https://github.com/sakuro) (ja)
- [sunnytan53](https://github.com/sunnytan53) (zh-CN)


