require("cables")
require("tin-ore")
require("tin-recipe")
require("tin-enriched")   -- Enriched Al for Krastorio 2
require("tin-recipe-se")         -- Space Exploration

local util = require("data-util");

-- Must be last
util.create_list()
