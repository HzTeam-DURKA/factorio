if mods["Clockwork"] and krastorio.general.getSafeSettingValue("Clockwork-disable-nv") then
  data.raw.technology["kr-imersite-night-vision-equipment"] = nil
end
