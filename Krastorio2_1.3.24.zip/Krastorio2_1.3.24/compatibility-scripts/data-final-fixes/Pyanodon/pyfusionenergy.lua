if mods["pyfusionenergy"] then
  -- Re-apply Krastorio science icons
  krastorio.icons.setItemIcon("production-science-pack", kr_cards_icons_path .. "production-tech-card.png")
end
