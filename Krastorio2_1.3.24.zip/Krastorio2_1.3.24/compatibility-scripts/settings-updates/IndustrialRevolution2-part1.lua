if mods["IndustrialRevolution"] then
  data.raw["string-setting"]["kr-automation-science-pack-recipe"].default_value = "Industrial Revolution"
  data.raw["string-setting"]["kr-automation-science-pack-recipe"].allowed_values = { "Industrial Revolution" }

  data.raw["string-setting"]["kr-logistic-science-pack-recipe"].default_value = "Industrial Revolution"
  data.raw["string-setting"]["kr-logistic-science-pack-recipe"].allowed_values = { "Industrial Revolution" }

  data.raw["string-setting"]["kr-military-science-pack-recipe"].default_value = "Industrial Revolution"
  data.raw["string-setting"]["kr-military-science-pack-recipe"].allowed_values = { "Industrial Revolution" }

  data.raw["string-setting"]["kr-chemical-science-pack-recipe"].default_value = "Industrial Revolution"
  data.raw["string-setting"]["kr-chemical-science-pack-recipe"].allowed_values = { "Industrial Revolution" }

  data.raw["string-setting"]["kr-production-science-pack-recipe"].default_value = "Industrial Revolution"
  data.raw["string-setting"]["kr-production-science-pack-recipe"].allowed_values = { "Industrial Revolution" }

  data.raw["string-setting"]["kr-utility-science-pack-recipe"].default_value = "Industrial Revolution"
  data.raw["string-setting"]["kr-utility-science-pack-recipe"].allowed_values = { "Industrial Revolution" }
end
