if mods["RealisticReactors"] then
  data.raw["boiler"]["heat-exchanger"].energy_consumption = "10MW"
end
