if mods["pyhightech"] then
  -- Fix bad code in science icons updating
  ---@diagnostic disable-next-line
  ITEM("utility-science-pack"):set("icon_size", 32)
end
