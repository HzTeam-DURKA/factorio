krastorio_utils = {}
require("private_stdlib.tables")
require("log")
