local util = require("data-util");

util.remove_ingredient("fu_carbon_fiber_recipe", "fi_crushed_coal_item")
util.add_ingredient("fu_carbon_fiber_recipe", "graphite", 3)
