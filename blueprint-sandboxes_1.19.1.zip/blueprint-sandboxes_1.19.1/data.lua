BPSB = require("scripts.bpsb")
ToggleGUI = require("scripts.toggle-gui")

require("prototypes.item-groups")
require("prototypes.shortcuts")
require("prototypes.styles")
require("prototypes.tips-and-tricks")
