require "__ModuleInserterSimplified__.prototypes.custom-input"
require "__ModuleInserterSimplified__.prototypes.tips-and-tricks"
require "__ModuleInserterSimplified__.prototypes.style"
require "__ModuleInserterSimplified__.prototypes.sprite"