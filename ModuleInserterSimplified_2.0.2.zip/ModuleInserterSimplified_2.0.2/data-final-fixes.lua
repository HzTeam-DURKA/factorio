require "__ModuleInserterSimplified__.prototypes.selection-tool"
