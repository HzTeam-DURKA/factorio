data:extend{
  {
    type = "sprite",
    name = "mis_configure_white",
    filename = "__ModuleInserterSimplified__/graphics/configure-button.png",
    size = 32,
    mipmap_count = 2,
    flags = { "gui-icon" },
  },
}