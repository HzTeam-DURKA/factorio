for _, player_data in pairs(global.player_data) do
  player_data.gui_position = nil
end