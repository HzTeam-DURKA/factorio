if omni and omni.matter then
  omni.matter.add_resource("zircon", omni.matter.get_ore_tier("iron-ore") or 1)
end
