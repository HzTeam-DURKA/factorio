require("zircon")
require("zircon-particle")
require("zirconium-recipe")
require("magazine")
require("zirconium-enriched")   -- Enriched for Krastorio 2
require("zirconium-recipe-se")  -- Space Exploration special recipes (depends on K2 if present)
-- require("zirconium-compressed")
