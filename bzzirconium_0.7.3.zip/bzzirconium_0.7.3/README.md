# Zirconium

[factorio mod page](https://mods.factorio.com/mod/bzzirconium)

## Version History
See changelog.txt

## Created by

- [brevven](https://mods.factorio.com/user/brevven) (code, design, graphics)

### Thanks to
- [snouz](https://mods.factorio.com/user/snouz) (recolored ore graphics, thumbnail style)
- Krastorio2 team for magazine icons, and some related code in magazine.lua (Licensed under GNU LGPL v3.0)

### Compatibility
- [nihilistzsche](https://github.com/nihilistzsche)

### Localization
- [Sakuro](https://github.com/sakuro) (ja)
- [yokmp](https://mods.factorio.com/user/yokmp) (de)
- [Thar0l](https://github.com/Thar0l) (ru)
- [PlexPt](https://github.com/PlexPt) (zh\_CN)
- [S3BA](https://github.com/S3BA-pl) (pl)
- [x2605](https://github.com/x2605) (ko)
- [Pergamum663](https://github.com/Pergamum663) (ru)
- [NathanU](https://github.com/NathanU) (de)
