# Titanium

[factorio mod page](https://mods.factorio.com/mod/bztitanium)

Adds titanium ore and plates to the base game. It requires lubricant to mine.
Most recipes that should be lightweight that use steel now use titanium. Other minor recipe tweaks as well.

## Version History
See changelog.txt

## Created by

- [brevven](https://mods.factorio.com/user/brevven) (code, design, graphics)
- [snouz](https://github.com/snouz) (graphics)

### Compatibility
- [nihilistzsche](https://github.com/nihilistzsche)

### Localization
- [thinOptimist](https://mods.factorio.com/user/thinOptimist) (ru)
- [yokmp](https://mods.factorio.com/user/yokmp) (de)
- [Sakuro](https://github.com/sakuro) (ja)
- [S3BA](https://github.com/S3BA-pl) (pl)
- [x2605](https://github.com/x2605) (ko)
- [CV514](https://github.com/CV514) (ru)
