require("foundry-updates")
