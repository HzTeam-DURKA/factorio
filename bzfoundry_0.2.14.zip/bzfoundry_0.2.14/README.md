# Foundry

[factorio mod page](https://mods.factorio.com/mod/bzfoundry)

## Version History
See changelog.txt

## License

This work is released under a CC license instead of MIT. Contact me on github if you have questions.

Attribution-ShareAlike 4.0 International (CC BY-SA 4.0) 
See LICENSE

## Created by

- [brevven](https://mods.factorio.com/user/brevven) (code, design, graphics)

### Localization

- [x2605](https://github.com/x2605) (ko)
- [Sakuro](https://github.com/sakuro) (ja)
- [Pergamum663](https://github.com/Pergamum663) (ru)
- [RiCZrd](https://mods.factorio.com/user/RiCZrd) (cs)
- [sunnytan53](https://github.com/sunnytan53) (zh-CN)
