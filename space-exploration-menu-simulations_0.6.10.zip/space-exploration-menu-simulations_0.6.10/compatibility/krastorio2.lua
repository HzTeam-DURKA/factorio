local menu_simulations = data.raw["utility-constants"]["default"].main_menu_simulations

menu_simulations.vita.save = "__space-exploration-menu-simulations__/menu-simulations/no-scripts/menu-simulation-vita-k2.zip"
menu_simulations.vulcanite_processing.save = "__space-exploration-menu-simulations__/menu-simulations/no-scripts/menu-simulation-vulcanite-processing-k2.zip"

menu_simulations.burner_base_night.save = "__space-exploration-menu-simulations__/menu-simulations/no-scripts/menu-simulation-burner-base-night-k2.zip"
menu_simulations.burner_base_night.init = nil
menu_simulations.burner_base_night.init_file = "__space-exploration-menu-simulations__/compatibility/menu-simulations-scripts/krastorio2-burner-base-night.lua"

menu_simulations.space_bio_sludge_loop.init = nil
menu_simulations.space_bio_sludge_loop.init_file = "__space-exploration-menu-simulations__/compatibility/menu-simulations-scripts/krastorio2-space-bio-sludge-loop.lua"

menu_simulations.scrap_processing.init = menu_simulations.scrap_processing.init .. "\n" ..
[[
    local chest = surface.create_entity({name="logistic-chest-requester", position={22.5,2.5}})
    chest.insert({name="coke", count=200})
    surface.create_entity({name="inserter", position={21.5,2.5}, direction=defines.direction.east})

    local furnace_a = surface.find_entity("electric-furnace",{19.5,-2.5})
    furnace_a.set_recipe("iron-plate")
    furnace_a.insert({name="iron-ore",count=10})

    local furnace_b = surface.find_entity("electric-furnace",{19.5,1.5})
    furnace_b.set_recipe("steel-plate")
    furnace_b.insert({name="iron-plate",count=5})
]]
