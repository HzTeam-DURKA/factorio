#!/bin/bash
for i in scripted/*.zip no-scripts/*.zip blank-templates/*.zip;
do
  zip -d "$i" "*/preview.jpg"
done