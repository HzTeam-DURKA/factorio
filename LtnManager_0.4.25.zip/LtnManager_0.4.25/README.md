# Factorio-LtnManager
A GUI for managing your Logistic Train Network. A mod for Factorio.
