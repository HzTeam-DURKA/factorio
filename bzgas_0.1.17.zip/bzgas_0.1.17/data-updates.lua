require("recipe-updates")
require("matter")
-- require("omni")
require("map-gen-preset-updates")
require("strange-matter")
require("compatibility/248k")
require("compatibility/5dims")
require("compatibility/sciencecosttweakerm")
require("compatibility/crafting-efficiency")
require("compatibility/bobe")

local util = require("data-util");

require("gas-boiler/data-updates")

-- Must be last
util.create_list()
