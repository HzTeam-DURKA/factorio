local util = require("data-util");

util.replace_ingredient("sct-t2-instruments", "iron-plate", "bakelite")


