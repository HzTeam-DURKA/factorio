local util = require("data-util");

if mods.bobelectronics then
  util.remove_ingredient("electronic-circuit", "bakelite")
end
