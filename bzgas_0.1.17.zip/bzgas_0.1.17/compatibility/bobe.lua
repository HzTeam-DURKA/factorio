local util = require("data-util");

if mods.bobelectronics then
  util.replace_ingredient("lab", "basic-circuit-board", "copper-cable")
end
