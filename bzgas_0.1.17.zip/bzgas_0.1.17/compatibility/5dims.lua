local util = require("data-util");

util.replace_ingredient("5d-accumulator-02", "iron-plate", "bakelite")
util.replace_ingredient("5d-accumulator-03", "iron-plate", "bakelite")
util.replace_ingredient("5d-lab-02", "iron-gear-wheel", "bakelite")
util.replace_ingredient("5d-lab-03", "steel-plate", "bakelite")
util.replace_ingredient("5d-radar-02", "iron-plate", "bakelite")
util.replace_ingredient("5d-radar-03", "steel-plate", "bakelite")
util.replace_ingredient("5d-radar-04", "steel-plate", "bakelite")
util.replace_ingredient("5d-radar-05", "steel-plate", "bakelite")
