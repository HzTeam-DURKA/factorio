# Natural Gas

[factorio mod page](https://mods.factorio.com/mod/bzgas)

Adds natural gas to the base game

## Version History
See changelog.txt

## Created by

- [brevven](https://mods.factorio.com/user/brevven) (code, design, graphics)
- [ElAdamo](https://mods.factorio.com/user/ElAdamo) (Gas-fired boiler: code, design, graphics) (code is public domain)

## Thanks to 
- [Sakuro](https://github.com/sakuro) (expand options, icon tweaks)
- [Benjah-bmm27](https://commons.wikimedia.org/wiki/User:Benjah-bmm27) ([Formaldehyde icon](https://commons.wikimedia.org/wiki/File:Formaldehyde-3D-vdW.png), public domain)

### Compatibility
- [nihilistzsche](https://github.com/nihilistzsche)

### Localization

- [RiCZrd](https://mods.factorio.com/user/RiCZrd) (cs)
- [Sakuro](https://github.com/sakuro) (ja)
- [Pergamum663](https://github.com/Pergamum663) (ru)
- [sunnytan53](https://github.com/sunnytan53) (zh-CN)
- [CV514](https://github.com/CV514) (ru)
