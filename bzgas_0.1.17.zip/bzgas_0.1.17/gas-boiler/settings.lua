data:extend({{
		name = "vanilla-fluid-fuel-values",
		type = "bool-setting",
		setting_type = "startup",
		default_value = false,
		order = "a"
}})