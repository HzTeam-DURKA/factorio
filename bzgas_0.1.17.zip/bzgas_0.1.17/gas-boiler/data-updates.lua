require("factsheet")
if settings.startup["vanilla-fluid-fuel-values"].value then
	apply_vanilla_fluid_fuel_stats()
end