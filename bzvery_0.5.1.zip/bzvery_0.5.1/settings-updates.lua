

-- Update various settings to give the "fullest" BZ mods experience
data.raw["string-setting"]["bzsilicon-more-intermediates"].default_value = "more"
data.raw["string-setting"]["bzlead-more-entities"].default_value = "yes"
data.raw["string-setting"]["bzfoundry-plates"].default_value = "yes"
data.raw["string-setting"]["bzcarbon-enable-carbon-black"].default_value = "yes"
data.raw["string-setting"]["bzcarbon-reuse"].default_value = "yes"
data.raw["string-setting"]["bztin-more-intermediates"].default_value = "bronze"
data.raw["string-setting"]["bztungsten-more-intermediates"].default_value = "cuw"
