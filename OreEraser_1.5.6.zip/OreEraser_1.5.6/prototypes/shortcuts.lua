data:extend(
{
    {
     	type = "shortcut",
    	name = "Ore Eraser",
    	order = "o[Ore Eraser]",
    	action = "spawn-item",
    	item_to_spawn = "Ore Eraser",
    	toggleable = true,
    	icon =
    	{
    		filename = "__OreEraser__/graphics/ore-eraser.png",
        	priority = "extra-high-no-scale",
        	size = 32,
        	scale = 1,
        	flags = { "icon" }
    	},
    	small_icon =
    	{
        	filename = "__OreEraser__/graphics/ore-eraser.png",
        	priority = "extra-high-no-scale",
        	size = 32,
        	scale = 1,
        	flags = { "icon" }
    	},
      	disabled_small_icon =
    	{
        	filename = "__OreEraser__/graphics/ore-eraser.png",
        	priority = "extra-high-no-scale",
        	size = 32,
        	scale = 1,
        	flags = { "icon" }
      	}
    }
})
