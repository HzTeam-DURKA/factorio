data:extend(
{
    {
        name = "oe-all-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = true,
        order = "a"
    },

    -- Vanilla
    {
        name = "oe-coal-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "b"
    },
    {
        name = "oe-copper-ore-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "c"
    },
    {
        name = "oe-crude-oil-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "d"
    },
    {
        name = "oe-iron-ore-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "e"
    },
    {
        name = "oe-stone-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "f"
    },
    {
        name = "oe-uranium-ore-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "g"
    },

    -- Krastorio 2
    {
        name = "oe-imersite-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "k21"
    },
    {
        name = "oe-rare-metals-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "k22"
    },
    {
        name = "oe-mineral-water-selected",
        type = "bool-setting",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "k23"
    },
})
