require("prototypes.ore-eraser")
require("prototypes.shortcuts")
