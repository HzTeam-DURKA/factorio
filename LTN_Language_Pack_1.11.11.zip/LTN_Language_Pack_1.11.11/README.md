# LTN Language Pack
  Localizations for LTN, LTN Manager, LTN Combinator mods for Factorio game

Download: https://mods.factorio.com/mod/LTN_Language_Pack
