# [Silica & Silicon](https://mods.factorio.com/mod/bzsilicon)

Mod for Factorio, adds a simple "Vanilla+" version of Silica and Silicon to the game with some fiber optics and optional intermediates.
Doesn't require or any new buildings.


## Version History
See changelog.

## Created by

- [brevven](https://mods.factorio.com/user/brevven) (code, design, graphics)
- [snouz](https://github.com/snouz) (graphics)

### Thanks to 
- [GeneralTank](https://mods.factorio.com/user/GeneralTank) (compatibility for stacking and crating, design contributions)
- [ZombieMooose](https://mods.factorio.com/user/ZombieMooose) (design contributions)
- [nihilistzsche](https://github.com/nihilistzsche) (compatibility)


### Localization

Thanks to
- [yokmp](https://mods.factorio.com/user/yokmp) (de)
- [Spectrus1702](https://github.com/Spectrus1702) (ru)
- [TheoMarque](https://github.com/TheoMarque) (pl)
- [Sakuro](https://github.com/sakuro) (ja)
- [PlexPt](https://github.com/PlexPt) (zh\_CN)
- [S3BA](https://github.com/S3BA-pl) (pl)
- [x2605](https://github.com/x2605) (ko)
- [Pergamum663](https://github.com/Pergamum663) (ru)
- [NathanU](https://github.com/NathanU) (de)
- [sunnytan53](https://github.com/sunnytan53) (zh\_CN)
