require("prototypes/cables")
require("prototypes/silica-recipe")
require("prototypes/silicon-recipe")
require("prototypes/optical-fiber")
require("prototypes/gyro")
require("recipes/silica-matter")

