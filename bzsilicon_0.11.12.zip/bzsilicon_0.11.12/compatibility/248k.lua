local util = require("data-util");

util.add_ingredient("fi_arc_glass_recipe", "silica", 7)
util.remove_ingredient("fi_arc_glass_recipe", "stone")
