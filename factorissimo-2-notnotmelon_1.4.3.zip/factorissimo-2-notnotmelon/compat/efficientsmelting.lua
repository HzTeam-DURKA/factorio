data.raw.item['factory-connection-indicator-settings'].stack_size = 1
data.raw.item['factory-overlay-controller-settings'].stack_size = 1
