if mods['EfficientSmelting'] then require('compat.efficientsmelting') end
