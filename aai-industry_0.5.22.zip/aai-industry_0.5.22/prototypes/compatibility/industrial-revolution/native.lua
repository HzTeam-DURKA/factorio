local items = {
	["sand"] = "silica",
	["motor"] = "copper-motor",
	["electric-motor"] = "iron-motor",
	["small-iron-electric-pole"] = "small-iron-pole",
}

local technologies = {
	["basic-logistics"] = {"IR_native"},
	["concrete-walls"] = {"IR_native"},
	["fuel-processing"] = {"IR_native"},
	["industrial-furnace"] = {"IR_native"},
	["steel-walls"] = {"IR_native"},
	
	["electric-lab"] = {"IR_disabled"},
	["electric-mining"] = {"IR_disabled"},
	["filter-inserter"] = {"IR_disabled"},
	["glass-processing"] = {"IR_disabled"},
	["medium-electric-pole"] = {"IR_disabled"},
	["radar"] = {"IR_disabled"},
	["sand-processing"] = {"IR_disabled"},
	["stack-filter-inserter"] = {"IR_disabled"},
	["steam-power"] = {"IR_disabled"},
}

for name, replacement in pairs(items) do
	data.raw.item[name].IR_replacement = replacement
end

for name, value in pairs(technologies) do
	local tech = data.raw.technology[name]
	tech[value[1]] = true
	if value[2] then
		tech.prerequisites = value[2]
	end
end
