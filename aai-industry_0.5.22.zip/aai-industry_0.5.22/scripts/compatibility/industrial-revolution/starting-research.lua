if not script.active_mods.IndustrialRevolution then
	return function() end
end

return function(player)
	if player and player.admin and settings.global["ir2-starting-age"].value ~= "burner" then
		for _,name in pairs{"basic-logistics", "basic-fluid-handling", "steam-handling", "steam-mining", "steam-research"} do
			local tech = player.force.technologies[name]
			if tech then tech.researched = true end
		end
	end
end
