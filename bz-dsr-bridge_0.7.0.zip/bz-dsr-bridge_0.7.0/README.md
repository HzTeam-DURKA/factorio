# BZMods DSR Bridge

[factorio mod page](https://mods.factorio.com/mod/bz-dsr-bridge)

Sets up optional dependencies on BZMods (Lead, Silica & Silicon, Titanium, Tungsten) for Deadlock Stacked Recipes or other mods to use. Does not currently provide any additional functionality on its own.

## Version History
See changelog.txt

## Created by

- [brevven](https://mods.factorio.com/user/brevven)

