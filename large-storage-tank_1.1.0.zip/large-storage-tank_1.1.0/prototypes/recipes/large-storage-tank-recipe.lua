data:extend({
	{
		type = "recipe",
		name = "large-storage-tank",
		energy_required = 8,
		enabled = false,
		ingredients = {
			{"concrete", 50},
			{"steel-plate", 20},
			{"iron-plate", 100}
		},
		result = "large-storage-tank",
	},
})
