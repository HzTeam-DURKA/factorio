local empty_sprite = {
   filename    = "__core__/graphics/empty.png",
   priority    = "extra-high",
   width       = 1,
   height      = 1,
   frame_count = 1
}

local storageTank = table.deepcopy(data.raw["storage-tank"]["storage-tank"])


storageTank.name = "large-storage-tank"
storageTank.minable.result = "large-storage-tank"
storageTank.max_health = 2000
storageTank.healing_per_tick = 0.01
storageTank.flags = { "placeable-player", "player-creation", "not-rotatable" }
storageTank.icon = "__large-storage-tank__/graphics/icons/icon.png"
local x = 2.5
local y = 2.5
storageTank.selection_box = {{-x,-y},{x,y}}
storageTank.collision_box = {{-x + 0.25, -y + 0.25},{x - 0.25, y - 0.25}}
local fluidSize = settings.startup["large-storage-tank-fluid-size"].value
local fluid_h = 1
local fluid_w = fluidSize/fluid_h/100

storageTank.fluid_box = {
   base_area = fluid_w,
   height = fluid_h,
   pipe_connections = {
      {position = {-3, -1}},
      {position = {-3, 1}},
      {position = {-1, -3}},
      {position = {1, -3}},
      {position = {3, -1}},
      {position = {3, 1}},
      {position = {-1, 3}},
      {position = {1, 3}},
   },
   pipe_covers = pipecoverspictures(),
}

storageTank.window_bounding_box = { { -0.4, 1.23 }, { 0.2, 1.87 } }

storageTank.pictures = {
   flow_sprite = empty_sprite,
   fluid_background = empty_sprite,
   gas_flow = empty_sprite,
   window_background = empty_sprite,


   picture = {
      sheets = {
         {
            filename = "__large-storage-tank__/graphics/entity/large-storage-tank.png",
            frames = 1,
            width = 256,
            height = 192,
            hr_version = {
               filename = "__large-storage-tank__/graphics/entity/hr-large-storage-tank.png",
               frames = 1,
               scale = 0.5,
               width = 512,
               height = 384,
            }
         },
         {
            filename = "__large-storage-tank__/graphics/entity/large-storage-tank-shadow.png",
            frames = 1,
            width = 256,
            height = 192,
            draw_as_shadow = true,
            hr_version = {
               filename = "__large-storage-tank__/graphics/entity/hr-large-storage-tank-shadow.png",
               frames = 1,
               scale = 0.5,
               width = 512,
               height = 384,
               draw_as_shadow = true,
            }
         }
      }
   },

   fluid_background = {
      filename = "__base__/graphics/entity/storage-tank/fluid-background.png",
      priority = "extra-high",
      width = 32,
      height = 15,
   },
   window_background = {
      filename = "__base__/graphics/entity/storage-tank/window-background.png",
      priority = "extra-high",
      width = 17,
      height = 24,
   },
   flow_sprite = {
      filename = "__base__/graphics/entity/pipe/fluid-flow-low-temperature.png",
      priority = "extra-high",
      width = 160,
      height = 20,
   },
   gas_flow = {
      filename = "__base__/graphics/entity/pipe/steam.png",
      priority = "extra-high",
      line_length = 10,
      width = 24,
      height = 15,
      frame_count = 60,
      axially_symmetrical = false,
      direction_count = 1,
      animation_speed = 0.25,
      hr_version = {
         filename = "__base__/graphics/entity/pipe/hr-steam.png",
         priority = "extra-high",
         line_length = 10,
         width = 48,
         height = 30,
         frame_count = 60,
         axially_symmetrical = false,
         animation_speed = 0.25,
         direction_count = 1,
      },
   },
}

data:extend{storageTank}
