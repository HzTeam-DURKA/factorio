data:extend({
	{
		type = "item-subgroup",
		name = "large-storage",
		group = "logistics",
		order = "zd",
	},
})