data:extend({
	{
		type = "technology",
		name = "large-storage-tank",
        icon = "__large-storage-tank__/graphics/icons/icon.png",
        icon_size = 64,
        icon_mipmaps = 4,
        prerequisites = {
            "fluid-handling",
            "concrete",
        },
        effects =
        {
          {
            type = "unlock-recipe",
            recipe = "large-storage-tank",
          }
        },
        unit =
        {
          count = 75,
          ingredients = {
            {"automation-science-pack", 1},
            {"logistic-science-pack", 1},
          },
          time = 30
        },
        order = "d-a-a",
	},
})
