data:extend({
	{
		type = "item",
		name = "large-storage-tank",
		icon = "__large-storage-tank__/graphics/icons/icon.png",
        icon_size = 64,
        icon_mipmaps = 4,
		subgroup = "storage",
		order = "b[fluid]-b[large-storage-tank]",
		place_result = "large-storage-tank",
		stack_size = 10
	}
})
