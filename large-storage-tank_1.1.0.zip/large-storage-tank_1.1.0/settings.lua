data:extend({
	{
		type = "int-setting",
		name = "large-storage-tank-fluid-size",
		setting_type = "startup",
		default_value = 100000,
		minimum_value = 1,
	}
})